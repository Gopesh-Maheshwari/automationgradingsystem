<?php
	include 'dbh.php';
	
$teacher=$_POST["teacher"];
$knowledge=$_POST["knowledge"];
$topicscovered=$_POST["topics"];
$doubtclearing=$_POST["doubt"];
$sql="insert into weekly(teacher,knowledge,topicscovered,doubtclearing) VALUES ('$teacher','$knowledge','$topicscovered','$doubtclearing')";
$conn->query($sql);
echo ' Data Entered';
?>