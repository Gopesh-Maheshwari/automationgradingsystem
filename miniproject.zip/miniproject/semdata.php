<?php
	include 'dbh.php';
	$teacher=$_POST["teacher"];
$fairness=$_POST['fairness'];
$knowledge=$_POST['knowledge'];
$doubtclearing=$_POST['doubt'];
$topics=$_POST['topics'];
$interaction=$_POST['interaction'];
$practicalknowledge=$_POST['practical'];
$overall=$_POST['overall'];
$sql="insert into semester(teacher,fairness,knowledge,topics,doubt,interaction,practicalknowledge,overall) VALUES ('$teacher','$fairness','$knowledge','$topics','$doubtclearing','$interaction','$practicalknowledge','$overall')";
$conn->query($sql);
echo ' Data Entered';
?>