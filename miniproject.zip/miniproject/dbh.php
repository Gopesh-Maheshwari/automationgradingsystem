<?php
	$conn= new mysqli('localhost','root','gsssv','miniproject');
	?>